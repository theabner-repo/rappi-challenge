import UIKit

var str = "Hello, playground"

func factorial(_ n: Int) -> Double {
    return n < 2 ? 1 : Double(n) * factorial(n - 1)
}

func countTeams(skills: [Int], minPlayers: Int, minLevel: Int, maxLevel: Int) -> Int {
    
    let allowedSkills = skills.filter { $0 >= minLevel && $0 <= maxLevel }
    
    let n = allowedSkills.count
    var r = minPlayers
    var result: Double = 0
    while r <= n {
        
        result += (factorial(n) / (factorial(r) * factorial(n - r)))
        r += 1
    }
    return Int(result)
}

print(countTeams(skills: [6, 4, 8, 7, 5, 2], minPlayers: 2, minLevel: 3, maxLevel: 10))
print(countTeams(skills: [248, 779, 392, 727, 561], minPlayers: 2, minLevel: 360, maxLevel: 1000))
print(countTeams(skills: [4, 8, 5, 6], minPlayers: 2, minLevel: 7, maxLevel: 8))
print(countTeams(skills: [4, 8, 5, 6], minPlayers: 2, minLevel: 5, maxLevel: 7))


